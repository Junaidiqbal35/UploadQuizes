
from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("profile/<str:username>/", views.other_user_profile, name="user_profile"),
    path('like/', views.bark_like, name='bark_like'),
    path('users/follow/', views.user_follow, name='user_follow'),
    path('following/barks/', views.following_barks, name='user_following_bark'),
    path('current-user/', views.current_user_profile, name='current_user_profile'),
    path('edit/<int:pk>/bark/', views.edit_bark, name='edit_bark')
]
