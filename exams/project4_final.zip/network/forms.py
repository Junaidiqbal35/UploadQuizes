from django import forms
from .models import Bark

# 1. New Post
class BarkForm(forms.ModelForm):
    class Meta:
        model = Bark
        fields = ['body']
        widgets = {
            'body': forms.Textarea(
                attrs={'placeholder': 'How is your pet today?'}
                )}
        labels = {
            'body': '',
        }