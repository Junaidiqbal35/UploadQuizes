from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.core.paginator import Paginator

from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .models import User, Bark
from .forms import BarkForm


def index(request):

    # 2. All Posts
    barks = Bark.objects.all()

    # 5. Pagination
    paginator = Paginator(barks, 10)
    page_number = request.GET.get('page', 1)
    barks = paginator.page(page_number)

    # 1. New Post
    if request.method == 'POST':
        bark_form = BarkForm(request.POST)
        if bark_form.is_valid():
            # Create bark_user but don't save yet
            bark_user = bark_form.save(commit=False)
            bark_user.user = request.user
            bark_user.save()

            messages.success(request, 'Post successfully added!')

            return render(request, "network/index.html", {
                "form": BarkForm,
                "barks": barks,
                # "messages": messages
            })
    
    else:
        form = BarkForm()
        return render(request, "network/index.html", {
            "form": form,
            "barks": barks
        })

    return render(request, "network/index.html")


# Provided code
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


# Provided code
def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


# Provided code
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")


# 3. Profile Page
@login_required
def other_user_profile(request, username):
    user = get_object_or_404(User, username = username, is_active = True)
    barks = Bark.objects.filter(user = user)

    # 5. Pagination
    paginator = Paginator(barks, 10)
    page_number = request.GET.get('page', 1)
    barks = paginator.page(page_number)

    return render(request, 'network/profile.html', {
        'user': user,
        'barks': barks
    })


# 4. Following

@csrf_exempt
@require_POST
@login_required
def user_follow(request):
    user_id = request.POST.get('id')
    action = request.POST.get('action')
    bark_user = User.objects.get(id=user_id)
    current_user = User.objects.get(username=request.user.username)
    if bark_user.id != current_user.id:
        if action == 'follow':
            current_user.following.add(bark_user.id)
        else:
            current_user.following.remove(bark_user.id)

        return JsonResponse({'status': 'ok'})

    return JsonResponse({'status': 'error'})


def following_barks(request):
    following_ids = request.user.following.values_list('id',
                                                       flat=True)
    users_following_bark = Bark.objects.filter(user_id__in=following_ids)

    # 5. Pagination
    paginator = Paginator(users_following_bark, 10)
    page_number = request.GET.get('page', 1)
    users_following_bark = paginator.page(page_number)

    return render(request,
                  'network/following_bark.html',
                  {'barks': users_following_bark})


# 6. Edit Post
@login_required
def current_user_profile(request):
    barks = Bark.objects.filter(user=request.user)

    # 5. Pagination
    paginator = Paginator(barks, 10)
    page_number = request.GET.get('page', 1)
    barks = paginator.page(page_number)

    return render(request, 'network/current_user_profile.html', {
        'barks': barks
    })


@csrf_exempt
def edit_bark(request, pk):
    bark = Bark.objects.get(id=pk)
    if bark.user.username == request.user.username:
        if request.method == "POST":
            form = BarkForm(request.POST, instance=bark)
            if form.is_valid():
                form.save()
                return JsonResponse({"message": "Yeah, that went well!"}, status=200)
            else:
                print(form.errors)
        else:
            form = BarkForm(instance=bark)
            return render(request, "network/current_user_profile.html", {
                "bark": bark,
                "form": form,
            })
    else:
        return HttpResponse('Oops, only the user that posted the bark can update it')


# 7. “Like” and “Unlike”
@csrf_exempt
@login_required
@require_POST
def bark_like(request):
    bark_id = request.POST.get('id')
    action = request.POST.get('action')
    if bark_id and action:
        bark = get_object_or_404(Bark, id=bark_id)
        if action == 'like':
            bark.users_like.add(request.user)
        else:
            bark.users_like.remove(request.user)
        return JsonResponse({'status': 'ok'})

    return JsonResponse({'status': 'error'})