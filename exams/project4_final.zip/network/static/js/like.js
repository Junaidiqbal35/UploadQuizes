// 7. “Like” and “Unlike”
/*jshint esversion: 6 */
document.addEventListener('DOMContentLoaded', (event) => {
    let url = '/like/';
    let options = {
        method: 'POST',
        mode: 'same-origin'
    };

// Have all <a> tag with dynamic bark id to like specific bark
    document.querySelectorAll("a.like").forEach(el => el.addEventListener('click', function (e) {
        e.preventDefault();
        let likeButton = this;

        // Which form to update
        let formData = new FormData();

        // Using action to use text as toggle
        formData.append('id', likeButton.dataset.id);
        formData.append('action', likeButton.dataset.action);
        options['body'] = formData;

        // send HTTP request
        fetch(url, options)
            .then(response => response.json())
            .then(data => {
                if (data['status'] === 'ok') {
                    let previousAction = likeButton.dataset.action;
                    // toggle button text and data-action
                    let action = previousAction === 'like' ? 'unlike' : 'like';
                    likeButton.dataset.action = action;
                    likeButton.innerHTML = action;
                    // update like count
                    let likeCount = document.querySelector(`#total-${likeButton.dataset.id}`);
                    let totalLikes = parseInt(likeCount.innerHTML);
                    likeCount.innerHTML = previousAction === 'like' ? totalLikes + 1 : totalLikes - 1;
                }
            });
    }));
});