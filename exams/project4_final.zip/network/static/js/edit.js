// 6. Edit Post
function edit_handler(element) {
    let id = element.getAttribute("data-id");
    let edit_btn = document.querySelector(`#edit-btn-${id}`);
  if (edit_btn.textContent === "Edit") {

    document.querySelector(`#bark-content-${id}`).style.display = "none";
    document.querySelector(`#bark-edit-${id}`).style.display = "block";

    edit_btn.textContent = "Save";

  } else if (edit_btn.textContent === "Save") {
    edit_bark(id, document.querySelector(`#bark-edit-${id}`).value);

    edit_btn.textContent = "Edit";
  }
}

function edit_bark(id, bark) {

     let url= `/edit/${id}/bark/`;
     let options = {
        method: 'POST',
        {#headers: {'X-CSRFToken': csrftoken},#}
        mode: 'same-origin'
      }

    const formData = new FormData();
    formData.append("id", id);
    formData.append("body", bark);
    options['body'] = formData;
    fetch(url, options).then((res) => {

        document.querySelector(`#bark-content-${id}`).textContent = bark;
        document.querySelector(`#bark-content-${id}`).style.display = "block";
        document.querySelector(`#bark-edit-${id}`).style.display = "none";
        document.querySelector(`#bark-edit-${id}`).textContent = bark;
    })

};

