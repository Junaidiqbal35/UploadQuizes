/*jshint esversion: 6 */
//4. following
document.addEventListener('DOMContentLoaded', (event) => {
    let url = '/users/follow/';
    let options = {
        method: 'POST',
        mode: 'same-origin'
    };

    // Find all <a> via the a.follow selector
    document.querySelector('a.follow').addEventListener('click', function (e) {
        // Prevent the default behavior of the <a> element
        e.preventDefault();
        // Store the reference to this
        let followButton = this;
        let formData = new FormData();

        // Passing id and action to the follow function
        formData.append('id', followButton.dataset.id);
        formData.append('action', followButton.dataset.action);
        options.body = formData;


        // Options object that will be passed with the Fetch API
        fetch(url, options)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'ok') {
                    let previousAction = followButton.dataset.action;
                    // Toggle button text and data-action
                    let action = previousAction === 'follow' ? 'unfollow' : 'follow';
                    followButton.dataset.action = action;
                    followButton.innerHTML = action;

                    // Update follower count
                    let followerCount = document.querySelector('span.count .total-follower');

                    // Parse integer value to increase the counter of followers
                    let totalFollowers = parseInt(followerCount.innerHTML);

                    // Increase of decrease the follower count
                    followerCount.innerHTML = previousAction === 'follow' ? totalFollowers + 1 : totalFollowers - 1;
                }
            });
    });

});