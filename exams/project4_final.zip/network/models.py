from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    # pass
    following = models.ManyToManyField(
        "self",
        blank=True,
        related_name="followers",
        symmetrical=False
    )


# 1. New Post
class Bark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    body = models.TextField(verbose_name='Bark')
    users_like = models.ManyToManyField(User, related_name='bark_liked', blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return f'Posted by {self.user}'
